<?php
global $connect;
session_start();
include("include/connectiondb.php");


if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>More Information</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        .doctor-profile {
            border: 1px solid #ddd;
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
        }
        .hospital-description {
            margin-top: 30px;
        }
        .message {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .message-success {
            background-color: #d4edda;
            color: #155724;
        }
        .message-error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .quotes {
            background-color: #f7f7f7;
            padding: 20px;
            text-align: center;
            margin-top: 40px;
            border-top: 1px solid #ddd;
        }
        .quote {
            font-style: italic;
            color: #555;
            margin: 15px 0;
        }
    </style>
</head>
<body>

<?php
include("include/header.php");
?>

<div class="container-fluid">


    <?php if (isset($message)): ?>
        <div class="message <?php echo strpos($message, 'Error') !== false ? 'message-error' : 'message-success'; ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <div class="hospital-description">
        <h2 class="text-center my-4">Welcome to Our Hospital</h2>
        <p class="text-center">Our hospital provides the best healthcare services with state-of-the-art medical facilities, experienced doctors, and compassionate care. We are dedicated to providing excellent treatment in a comfortable and supportive environment.</p>
    </div>


    <h3 class="text-center my-4">Meet Our Doctors</h3>
    <div class="row">
        <?php

        $query = "SELECT * FROM doctors";
        $result = mysqli_query($connect, $query);

        if (!$result) {
            die("Query failed: " . mysqli_error($connect));
        }

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div class='col-md-4 doctor-profile'>";
            echo "<h4>" . $row['firstname'] . " " . $row['lastname'] . "</h4>";
            echo "<p><strong>Phone:</strong> " . $row['phone'] . "</p>";
            echo "<p><strong>Country:</strong> " . $row['country'] . "</p>";
            echo "<p><strong>Email:</strong> " . $row['email'] . "</p>";
            echo "<p><strong>Status:</strong> " . $row['status'] . "</p>";
            echo "</div>";
        }
        ?>
    </div>
</div>


<div class="quotes">
    <h3>Inspirational Quotes by Doctors</h3>
    <div class="quote">"The best way to predict the future is to create it." – Abraham Lincoln</div>
    <div class="quote">"Wherever the art of medicine is loved, there is also a love of humanity." – Hippocrates</div>
    <div class="quote">"To cure sometimes, to relieve often, to comfort always." – Edward Livingston Trudeau</div>
    <div class="quote">"A physician is obligated to consider more than a diseased organ, more even than the whole man – he must view the man in his world." – Harvey Cushing</div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>
