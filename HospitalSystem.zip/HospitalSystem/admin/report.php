<?php
global $connect;
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <title>Report Page</title>
</head>
<body>
<?php
include("../include/header.php");
include("../include/connectiondb.php");
?>

<div class="container-fluid">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px;">
                <?php
                include("../admin/sidenav.php");
                ?>
            </div>
            <div class="col-md-10">
                <h5 class="text-center my-3">Patient Reports</h5>

                <?php
                $query = "SELECT * FROM report";
                $result = mysqli_query($connect, $query);

                echo "<table class='table table-bordered'>
                                <tr>
                                    <th>ID Patient</th>
                                    <th>Title</th>
                                    <th>Message</th>
                                    <th>Username</th>
                                    <th>Date Sent</th>
                                </tr>";

                if (mysqli_num_rows($result) < 1) {
                    echo "<tr><td colspan='5' class='text-center'>No Reports Yet</td></tr>";
                } else {
                    while ($row = mysqli_fetch_array($result)) {
                        echo "<tr>
                                        <td>" . $row['id'] . "</td>
                                        <td>" . htmlspecialchars($row['title']) . "</td>
                                        <td>" . htmlspecialchars($row['message']) . "</td>
                                        <td>" . htmlspecialchars($row['username']) . "</td>
                                        <td>" . $row['date_send'] . "</td>
                                      </tr>";
                    }
                }
                echo "</table>";
                ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
