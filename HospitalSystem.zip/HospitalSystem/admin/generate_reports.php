<?php
global $connect;
include("../include/connectiondb.php");
session_start();

// Proveri da li je admin prijavljen
if (!isset($_SESSION['admin'])) {
    die("Access denied. You must be an admin.");
}

$doctor_ids = [1, 2, 3, 4, 5]; // Lista postojećih doktora (promeni prema tvojoj bazi)
$usernames = ["john_doe", "alice_smith", "michael_brown", "sara_jones", "david_clark"];
$titles = ["Medical Issue", "Checkup Request", "Follow-up", "Medication Query", "Emergency Concern"];
$messages = [
    "I need a follow-up appointment.",
    "Can you review my latest test results?",
    "I have an issue with my medication.",
    "I'm experiencing unusual symptoms.",
    "I'd like to discuss a new treatment plan."
];

for ($i = 0; $i < 250; $i++) {
    $title = mysqli_real_escape_string($connect, $titles[array_rand($titles)]);
    $message = mysqli_real_escape_string($connect, $messages[array_rand($messages)]);
    $username = mysqli_real_escape_string($connect, $usernames[array_rand($usernames)]);
    $doctor_id = $doctor_ids[array_rand($doctor_ids)];
    $rating = rand(1, 5);

    $query = "INSERT INTO report (title, message, username, doctor_id, rating, date_send) 
              VALUES ('$title', '$message', '$username', '$doctor_id', '$rating', NOW())";

    mysqli_query($connect, $query) or die("Error: " . mysqli_error($connect));
}

echo "250 reports have been generated successfully!";
?>
