<?php

global $connect;
include ("../include/connectiondb.php");


$id = $_POST['id'];

$query = "UPDATE doctors SET status = 'Approved' WHERE id = '$id'";


mysqli_query($connect, $query);
?>
