<?php
global $connect;
session_start();
include("../include/connectiondb.php");

$query = "SELECT * FROM income";
$result = mysqli_query($connect, $query);

?>

<!doctype html>
<html lang="en">
<head>
    <title>Income Records</title>
</head>
<body>
<?php
include("../include/header.php");
include("../include/connectiondb.php");
?>

<div class="container-fluid">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px;">
                <?php include("../admin/sidenav.php"); ?>
            </div>
            <div class="col-md-10">
                <h5 class="text-center my-3">Income Records</h5>

                <?php
                if (mysqli_num_rows($result) < 1) {
                    echo "<div class='alert alert-warning text-center'>No income records yet.</div>";
                } else {
                    echo "<table class='table table-bordered'>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Doctor</th>
                                    <th>Patient</th>
                                    <th>Date of Discharge</th>
                                    <th>Amount Paid</th>
                                </tr>
                            </thead>
                            <tbody>";

                    while ($row = mysqli_fetch_array($result)) {
                        echo "<tr>
                                <td>" . $row['id'] . "</td>
                                <td>" . htmlspecialchars($row['doctor']) . "</td>
                                <td>" . htmlspecialchars($row['patient']) . "</td>
                                <td>" . $row['date_discharge'] . "</td>
                                <td>$" . number_format($row['amount_paid'], 2) . "</td>
                              </tr>";
                    }
                    echo "</tbody></table>";
                }
                ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
