<?php
global $connect;
include("../include/connectiondb.php");
session_start();

function randomString($length) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$genders = ['Male', 'Female'];
$countries = ['USA', 'Canada', 'UK', 'Germany', 'France', 'Italy', 'Spain'];

for ($i = 0; $i < 500; $i++) {
    $firstname = randomString(rand(5, 8));
    $lastname = randomString(rand(5, 10));
    $username = strtolower($firstname . "_" . $lastname . rand(10, 99));
    $email = $username . "@example.com";
    $phone = "+1" . rand(1000000000, 9999999999);
    $gender = $genders[array_rand($genders)];
    $country = $countries[array_rand($countries)];
    $password = password_hash("password123", PASSWORD_BCRYPT);
    $profile = "default.jpg";


    $year = rand(2020, 2025);
    $month = str_pad(rand(1, 12), 2, "0", STR_PAD_LEFT);
    $day = str_pad(rand(1, 28), 2, "0", STR_PAD_LEFT);
    $hour = str_pad(rand(0, 23), 2, "0", STR_PAD_LEFT);
    $minute = str_pad(rand(0, 59), 2, "0", STR_PAD_LEFT);
    $second = str_pad(rand(0, 59), 2, "0", STR_PAD_LEFT);

    $date_reg = "$year-$month-$day $hour:$minute:$second";

    $query = "INSERT INTO patient (firstname, lastname, username, email, phone, gender, country, password, date_reg, profile) 
              VALUES ('$firstname', '$lastname', '$username', '$email', '$phone', '$gender', '$country', '$password', '$date_reg', '$profile')";

    mysqli_query($connect, $query) or die("Error: " . mysqli_error($connect));
}

echo "500 random patients have been created successfully!";
?>
