<?php
global $connect;
include("../include/connectiondb.php");
session_start();

// Proveri da li je admin prijavljen
if (!isset($_SESSION['admin'])) {
    die("Access denied. You must be an admin.");
}

$doctor_ids = [1, 2, 3, 4, 5]; // Lista postojećih doktora (promeni prema tvojoj bazi)
$patient_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]; // Lista postojećih pacijenata (promeni prema tvojoj bazi)
$amounts = [50, 75, 100, 150, 200]; // Moguće iznose naplate

for ($i = 0; $i < 200; $i++) {

    $patient_id = $patient_ids[array_rand($patient_ids)];
    $doctor_id = $doctor_ids[array_rand($doctor_ids)];


    $amount_paid = $amounts[array_rand($amounts)];


    $start_date = strtotime("2020-01-01");
    $end_date = strtotime("2025-12-31");
    $random_date = rand($start_date, $end_date);
    $date_discharge = date('Y-m-d', $random_date);

    // Unos u bazu podataka
    $income_query = "INSERT INTO income (doctor, patient, date_discharge, amount_paid) 
                     VALUES ('$doctor_id', '$patient_id', '$date_discharge', '$amount_paid')";
    mysqli_query($connect, $income_query) or die("Error: " . mysqli_error($connect));
}

echo "200 invoices have been generated successfully!";
?>
