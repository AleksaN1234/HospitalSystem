<?php
global $connect;
session_start();
include("../include/connectiondb.php");

$currentYear = date("Y");
$startYear = $currentYear - 5;

$selectedYearSalary = isset($_GET['yearSalary']) ? $_GET['yearSalary'] : 'all';
$selectedYearPatients = isset($_GET['yearPatients']) ? $_GET['yearPatients'] : 'all';

// Učitavanje podataka za prihode bolnice
$queryHospitalRevenue = "SELECT YEAR(date_reg) AS year, MONTH(date_reg) AS month, COUNT(id) * 100 AS revenue 
                         FROM patient 
                         WHERE YEAR(date_reg) BETWEEN $startYear AND $currentYear
                         GROUP BY YEAR(date_reg), MONTH(date_reg)
                         ORDER BY YEAR(date_reg) ASC, MONTH(date_reg) ASC";
$resultHospitalRevenue = mysqli_query($connect, $queryHospitalRevenue);
$hospitalRevenueData = [];
while ($row = mysqli_fetch_assoc($resultHospitalRevenue)) {
    $hospitalRevenueData[] = $row;
}

// Učitavanje podataka za pacijente
$queryPatients = "SELECT YEAR(date_reg) AS year, MONTH(date_reg) AS month, COUNT(id) AS num_patients 
                  FROM patient 
                  WHERE YEAR(date_reg) BETWEEN $startYear AND $currentYear
                  GROUP BY YEAR(date_reg), MONTH(date_reg)
                  ORDER BY YEAR(date_reg) ASC, MONTH(date_reg) ASC";
$resultPatients = mysqli_query($connect, $queryPatients);
$patientsData = [];
while ($row = mysqli_fetch_assoc($resultPatients)) {
    $patientsData[] = $row;
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistics</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<?php include("../include/header.php"); ?>

<div class="container mt-5">
    <h2 class="text-center">Hospital Statistics (Last 5 Years)</h2>

    <!-- Filter za prihode -->
    <div class="text-center mb-4">
        <form method="GET">
            <label for="yearSalary">Select Year for Hospital Revenue Chart:</label>
            <select name="yearSalary" id="yearSalary" class="form-control d-inline-block w-25">
                <option value="all" <?= ($selectedYearSalary == 'all') ? 'selected' : '' ?>>All</option>
                <?php for ($y = $currentYear; $y >= $startYear; $y--): ?>
                    <option value="<?= $y ?>" <?= ($selectedYearSalary == $y) ? 'selected' : '' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
            <button type="submit" class="btn btn-primary">Filter Revenue Chart</button>
        </form>
    </div>

    <h3 class="text-center mt-4">Hospital Revenue (Pie Chart)</h3>
    <canvas id="revenueChart" width="400" height="400"></canvas>

    <!-- Filter za broj pacijenata -->
    <div class="text-center mb-4 mt-5">
        <form method="GET">
            <label for="yearPatients">Select Year for Patients Chart:</label>
            <select name="yearPatients" id="yearPatients" class="form-control d-inline-block w-25">
                <option value="all" <?= ($selectedYearPatients == 'all') ? 'selected' : '' ?>>All</option>
                <?php for ($y = $currentYear; $y >= $startYear; $y--): ?>
                    <option value="<?= $y ?>" <?= ($selectedYearPatients == $y) ? 'selected' : '' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
            <button type="submit" class="btn btn-primary">Filter Patients Chart</button>
        </form>
    </div>

    <h3 class="text-center mt-4">Number of Patients per Year</h3>
    <canvas id="patientsChart" width="400" height="200"></canvas>
</div>

<script>

    const hospitalRevenueData = <?php echo json_encode($hospitalRevenueData); ?>;
    const patientsData = <?php echo json_encode($patientsData); ?>;
    const selectedYearSalary = "<?php echo $selectedYearSalary; ?>";
    const selectedYearPatients = "<?php echo $selectedYearPatients; ?>";

    console.log("Filtered Hospital Revenue Data:", hospitalRevenueData);
    console.log("Filtered Patients Data:", patientsData);

    function filterDataByYear(data, year) {
        if (year === "all") {
            return data;
        }
        return data.filter(item => item.year == year);
    }

    const filteredHospitalRevenueData = filterDataByYear(hospitalRevenueData, selectedYearSalary);
    const filteredPatientsData = filterDataByYear(patientsData, selectedYearPatients);


    const revenueLabels = filteredHospitalRevenueData.map(item => `${item.month}-${item.year}`);
    const revenueValues = filteredHospitalRevenueData.map(item => item.revenue);


    const patientsLabels = filteredPatientsData.map(item => `${item.month}-${item.year}`);
    const patientsValues = filteredPatientsData.map(item => item.num_patients);


    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    new Chart(revenueCtx, {
        type: 'pie',
        data: {
            labels: revenueLabels,
            datasets: [{
                label: 'Hospital Revenue',
                data: revenueValues,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)', 'rgba(54, 162, 235, 0.2)', 'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)', 'rgba(153, 102, 255, 0.2)', 'rgba(255, 159, 64, 0.2)',
                    'rgba(100, 255, 100, 0.2)', 'rgba(250, 50, 250, 0.2)', 'rgba(240, 150, 50, 0.2)',
                    'rgba(200, 100, 200, 0.2)', 'rgba(50, 200, 150, 0.2)', 'rgba(0, 200, 255, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)',
                    'rgba(100, 255, 100, 1)', 'rgba(250, 50, 250, 1)', 'rgba(240, 150, 50, 1)',
                    'rgba(200, 100, 200, 1)', 'rgba(50, 200, 150, 1)', 'rgba(0, 200, 255, 1)'
                ],
                borderWidth: 1
            }]
        }
    });


    const patientsCtx = document.getElementById('patientsChart').getContext('2d');
    new Chart(patientsCtx, {
        type: 'line',
        data: {
            labels: patientsLabels,
            datasets: [{
                label: 'Number of Patients',
                data: patientsValues,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Month-Year'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Number of Patients'
                    },
                    beginAtZero: true
                }
            }
        }
    });
</script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>
