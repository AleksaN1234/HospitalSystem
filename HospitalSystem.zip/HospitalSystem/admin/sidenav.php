<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
</head>
<body>
    <div class="list-group bg-info" style="height: 90vh;">
        <a href="../admin/index.php" class="list-group-item list-group-item-action bg-info text-center text-white">Dashboard</a>
        <a href="profile.php" class="list-group-item list-group-item-action bg-info text-center text-white">Profile</a>
        <a href="admin.php" class="list-group-item list-group-item-action bg-info text-center text-white">Administrators</a>
        <a href="doctor.php" class="list-group-item list-group-item-action bg-info text-center text-white">Doctors</a>
        <a href="patient.php" class="list-group-item list-group-item-action bg-info text-center text-white">Patients</a>
        <a href="statistics.php" class="list-group-item list-group-item-action bg-info text-center text-white">Statistics</a>
    </div>

</body>
</html>
