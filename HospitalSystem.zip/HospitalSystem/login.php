<?php
session_start();
include("include/connectiondb.php");
global $connect;

$error = array();
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($connect, $_POST['username']);
    $password = mysqli_real_escape_string($connect, $_POST['password']);
    $user_type = $_POST['user_type']; // Nova promenljiva koja odražava tip korisnika (admin, doctor, patient)

    if ($user_type == 'admin') {
        $query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
        $result = mysqli_query($connect, $query);
        if (mysqli_num_rows($result) == 1) {
            $_SESSION['admin'] = $username;
            header("Location: admin/index.php");
            exit();
        } else {
            $error['login'] = 'Invalid username or password for Admin';
        }
    } elseif ($user_type == 'doctor') {
        $q = "SELECT * FROM doctors WHERE username='$username'";
        $qq = mysqli_query($connect, $q);
        $row = mysqli_fetch_array($qq);

        if (!$row || !password_verify($password, $row['password'])) {
            $error['login'] = 'Invalid username or password for Doctor';
        } else if ($row['status'] == "Pending") {
            $error['login'] = 'Your account is pending';
        } else if ($row['status'] == "Rejected") {
            $error['login'] = 'Your account is rejected';
        } else {
            $_SESSION['doctor'] = $username;
            header("Location: doctor/index.php");
            exit();
        }
    } elseif ($user_type == 'patient') {
        $q = "SELECT * FROM patient WHERE username='$username'";
        $qq = mysqli_query($connect, $q);
        $row = mysqli_fetch_array($qq);

        if (!$row || !password_verify($password, $row['password'])) {
            $error['login'] = 'Invalid username or password for Patient';
        } else {
            $_SESSION['patient'] = $username;
            header("Location: patient/index.php");
            exit();
        }
    }
}

$show = isset($error['login']) ? "<h5 class='text-center alert alert-danger'>{$error['login']}</h5>" : '';
?>

<!doctype html>
<html lang="en">
<head>
    <title>Login Page</title>
</head>
<body style="background-image: url(img/back.jpg);background-size: cover;background-repeat: no-repeat;">
<?php include ("include/header.php"); ?>

<div class="container-fluid">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6 jumbotron my-3">
                <h5 class="text-center my-2">Login</h5>
                <div>
                    <?php echo $show; ?>
                </div>
                <form method="post">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" autocomplete="off" placeholder="Enter Username">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" autocomplete="off" placeholder="Enter Password">
                    </div>
                    <div class="form-group">
                        <label for="user_type">Select User Type</label>
                        <select name="user_type" class="form-control">
                            <option value="admin">Admin</option>
                            <option value="doctor">Doctor</option>
                            <option value="patient">Patient</option>
                        </select>
                    </div>
                    <input type="submit" name="login" class="btn btn-success" value="Login">
                    <p>If you don't have an account, <a href="apply.php">Apply Now!!!</a></p>
                </form>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</div>
</body>
</html>
