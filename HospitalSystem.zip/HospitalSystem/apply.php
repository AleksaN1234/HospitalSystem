<?php
session_start();
include("include/connectiondb.php");
global $connect;
if (isset($_POST['apply'])) {
    $firstname = mysqli_real_escape_string($connect, $_POST['fname']);
    $lastname = mysqli_real_escape_string($connect, $_POST['sname']);
    $username = mysqli_real_escape_string($connect, $_POST['uname']);
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $gender = mysqli_real_escape_string($connect, $_POST['gender']);
    $phone = mysqli_real_escape_string($connect, $_POST['phone']);
    $country = mysqli_real_escape_string($connect, $_POST['country']);
    $password = mysqli_real_escape_string($connect, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($connect, $_POST['confirm_password']);

    $error = array();

    if (empty($firstname)) $error['apply'] = "First Name is required";
    if (empty($lastname)) $error['apply'] = "Last Name is required";
    if (empty($username)) $error['apply'] = "Username is required";
    if (empty($email)) $error['apply'] = "Email is required";
    if (empty($gender)) $error['apply'] = "Gender is required";
    if (empty($phone)) $error['apply'] = "Phone Number is required";
    if (empty($password)) $error['apply'] = "Password is required";
    if (empty($confirm_password)) $error['apply'] = "Confirm Password is required";
    if ($password !== $confirm_password) $error['apply'] = "Passwords do not match";

    if (count($error) == 0) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash lozinke
        $query = "INSERT INTO doctors (firstname, lastname, username, email, gender, phone, country, password, salary, data_reg, status, profile) 
                  VALUES ('$firstname', '$lastname', '$username', '$email', '$gender', '$phone', '$country', '$hashed_password', '0', NOW(), 'Pending', 'img/doctor.jpg')";

        $result = mysqli_query($connect, $query);

        if ($result) {
            echo "<script>alert('You have Successfully Applied');</script>";
            header("location: doctorlogin.php");
        } else {
            echo "<script>alert('Failed Application');</script>";
        }
    }
}

$show = isset($error['apply']) ? "<h5 class='text-center alert alert-danger'>{$error['apply']}</h5>" : '';
?>

<!doctype html>
<html lang="en">
<head>
    <title>Apply Now</title>
</head>
<body style="background-image: url(img/back.jpg); background-size: cover; background-repeat: no-repeat;">

    <?php
        include("include/header.php");
    ?>
    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6 my-3 jumbotron">
                    <h5 class="text-center">Apply Now</h5>
                        <div>
                            <?php echo $show; ?>
                        </div>
                    <form method="post">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="fname" class="form-control" autocomplete="off" placeholder="Enter First Name" value="<?php if(isset($_POST['fname'])) echo $_POST['fname'];?>">
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="sname" class="form-control" autocomplete="off" placeholder="Enter Last Name"value="<?php if(isset($_POST['sname'])) echo $_POST['sname'];?>">
                        </div>
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="uname" class="form-control" autocomplete="off" placeholder="Enter Your Username"value="<?php if(isset($_POST['uname'])) echo $_POST['uname'];?>">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" autocomplete="off" placeholder="Enter Email Address"value="<?php if(isset($_POST['email'])) echo $_POST['email'];?>">
                        </div>
                        <div class="form-group">
                            <label>Select Gender</label>
                            <select name="gender" class="form-control">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="tel" name="phone" class="form-control" autocomplete="off" placeholder="Enter Phone Number" value="<?php if(isset($_POST['phone'])) echo $_POST['phone'];?>">
                        </div>
                        <div class="form-group">
                            <label>Select Country</label>
                            <select name="country" class="form-control">
                                <option value="Serbia">Serbia</option>
                                <option value="USA">United States</option>
                                <option value="Croatia">Croatia</option>
                                <option value="Bosnia">Bosnia</option>
                                <option value="Montenegro">Montenegro</option>
                                <option value="Greece">Greece</option>
                                <option value="Hungary">Hungary</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" autocomplete="off" placeholder="Enter Password" >
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" name="confirm_password" class="form-control" autocomplete="off" placeholder="Confirm Password">
                        </div>
                        <input type="submit" name="apply" value="Apply" class="btn btn-success">
                        <p>I already have an account <a href="doctorlogin.php">Click Here</a></p>
                    </form>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </div>
</body>
</html>