<?php
global $connect;
session_start();
include("../include/connectiondb.php");


$query = "SELECT * FROM appointment WHERE status = 'Pending'";
$result = mysqli_query($connect, $query);


if (!$result) {
    die("Query failed: " . mysqli_error($connect));
}
?>

<!doctype html>
<html lang="en">
<head>
    <title>Doctor Appointment Page</title>
</head>
<body>
<?php
include("../include/header.php");
?>

<div class="container-fluid">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px;">
                <?php
                include("../doctor/sidenav.php");
                ?>
            </div>
            <div class="col-md-10">
                <h3 class="text-center my-3">Pending Appointments</h3>

                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Phone</th>
                        <th>Appointment Date</th>
                        <th>Symptoms</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Prolazak kroz sve rezultate iz baze
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['id'] . "</td>";
                            echo "<td>" . $row['firstname'] . "</td>";
                            echo "<td>" . $row['lastname'] . "</td>";
                            echo "<td>" . $row['phone'] . "</td>";
                            echo "<td>" . $row['appointment_date'] . "</td>";
                            echo "<td>" . $row['symptoms'] . "</td>";

                            echo "<td><a href='discharge.php?id=" . $row['id'] . "' class='btn btn-primary'>Check</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>No pending appointments found</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
