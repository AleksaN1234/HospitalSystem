<?php
session_start();
include("../include/connectiondb.php");
global $connect;

if (!$connect) {
    die("Database connection error: " . mysqli_connect_error());
}

?>
<!doctype html>
<html lang="en">
<head>
    <title>Doctor's Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<?php include("../include/header.php"); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-2" style="margin-left: -30px;">
            <?php include("../doctor/sidenav.php"); ?>
        </div>
        <div class="col-md-10">
            <div class="container-fluid">
                <h5>Doctor's Dashboard</h5>
                <div class="col-md-12">
                    <div class="row">


                        <div class="col-md-3 my-2 bg-info mx-2" style="height: 150px;">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5 class="text-white my-4">My Profile</h5>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="profile.php"><i class="fa fa-user-circle fa-3x my-4" style="color: white"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-3 my-2 bg-danger mx-2" style="height: 150px;">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-8">
                                        <?php

                                        $appo = mysqli_query($connect, "SELECT * FROM appointment WHERE status='Pending'");

                                        $sr = mysqli_num_rows($appo);

                                        ?>
                                        <h5 class="text-white my-2" style="font-size: 30px;"><?php echo $sr; ?></h5>
                                        <h5 class="text-white">Total</h5>
                                        <h5 class="text-white my-2">Appointments</h5>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="../doctor/appointment.php"><i class="fa fa-calendar fa-3x my-4" style="color: white"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-3 my-2 bg-success mx-2" style="height: 150px;">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-8">
                                        <?php
                                        $patient_query = mysqli_query($connect, "SELECT * FROM patient");

                                        if (!$patient_query) {
                                            die("Query failed: " . mysqli_error($connect));
                                        }

                                        $num_patients = mysqli_num_rows($patient_query);
                                        ?>
                                        <h5 class="text-white" style="font-size: 30px;"><?php echo $num_patients; ?></h5>
                                        <h5 class="text-white">Total</h5>
                                        <h5 class="text-white">Patients</h5>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="patient.php"><i class="fa fa-procedures fa-3x my-4" style="color: white"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
