<?php
global $connect;
session_start();
include("../include/connectiondb.php");

if (isset($_GET['id'])) {
    $appointment_id = mysqli_real_escape_string($connect, $_GET['id']);

    $query = "SELECT * FROM appointment WHERE id = '$appointment_id'";
    $result = mysqli_query($connect, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $appointment = mysqli_fetch_assoc($result);
    } else {
        echo "<div class='alert alert-danger'>No appointment found!</div>";
        exit();
    }

    if (isset($_POST['submit'])) {
        $fee = mysqli_real_escape_string($connect, $_POST['fee']);

        $update_query = "UPDATE appointment SET status = 'Discharged', doctor_fee = '$fee' WHERE id = '$appointment_id'";

        if (mysqli_query($connect, $update_query)) {

            $doctor = $_SESSION['doctor'];
            $patient = $appointment['username'];
            $date_discharge = date('Y-m-d');

            $income_query = "INSERT INTO income (doctor, patient, date_discharge, amount_paid) 
                             VALUES ('$doctor', '$patient', '$date_discharge', '$fee')";
            if (mysqli_query($connect, $income_query)) {
                header("Location: appointment.php");
                exit();
            } else {
                echo "<div class='alert alert-danger'>Error logging income: " . mysqli_error($connect) . "</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>Error updating status: " . mysqli_error($connect) . "</div>";
        }
    }
} else {
    echo "<div class='alert alert-danger'>Appointment ID not provided!</div>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discharge Appointment</title>
    <!-- Include your CSS files here -->
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php
include("../include/header.php");
?>

<div class="container">
    <h2 class="text-center">Discharge Appointment</h2>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Appointment ID</th>
                    <th>Patient First Name</th>
                    <th>Patient Last Name</th>
                    <th>Symptoms</th>
                    <th>Appointment Date</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo $appointment['id']; ?></td>
                    <td><?php echo $appointment['firstname']; ?></td>
                    <td><?php echo $appointment['lastname']; ?></td>
                    <td><?php echo $appointment['symptoms']; ?></td>
                    <td><?php echo $appointment['appointment_date']; ?></td>
                </tr>
                </tbody>
            </table>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="fee">Doctor's Fee</label>
                    <input type="number" name="fee" id="fee" class="form-control" required>
                </div>

                <button type="submit" name="submit" class="btn btn-success">Discharge</button>
                <a href="appointment.php" class="btn btn-danger">Cancel</a>
            </form>
        </div>
    </div>
</div>

<!-- Include any required JS files -->
<script src="../js/script.js"></script>
</body>
</html>
