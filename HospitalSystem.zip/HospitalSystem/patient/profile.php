<?php
global $connect;
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <title>Patient Profile</title>
</head>
<body>
<?php
 include("../include/header.php");
 include("../include/connectiondb.php");
?>


    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-2" style="margin-left: -30px;">
                    <?php
                    include("../patient/sidenav.php");

                        $patient = $_SESSION['patient'];
                        $query = "SELECT * FROM `patient` WHERE `username`='$patient'";

                        $result = mysqli_query($connect, $query);

                        $row = mysqli_fetch_array($result);
                    ?>
                </div>
                <div class="col-md-10">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6">
                                <?php
                                     if(isset($_POST['upload'])){
                                         $img = $_FILES['img']['name'];

                                         if(empty($img)){

                                         }else{
                                             $query = "UPDATE `patient` SET profile='$img' WHERE `username`='$patient'";
                                             $result = mysqli_query($connect, $query);

                                             if($result){
                                                 move_uploaded_file($_FILES['img']['tmp_name'], '../img/'.$img);
                                             }
                                         }
                                     }
                                ?>
                                <h5 class="text-center">My Profile</h5>
                                <form method="post" enctype="multipart/form-data">
                                    <?php
                                        echo "<img src='../img/".$row['profile']."' class='col-md-12' style='height: 250px;'>"
                                    ?>
                                    <input type="file" name="img" class="form-control my-2">
                                    <input type="submit" name="upload" class="btn btn-info" value="Update Profile">
                                </form>


                                <table class="table table-bordered">
                                    <tr>
                                        <th colspan="2" class="text-center">My Details</th>
                                    </tr>
                                    <tr>
                                        <td>First Name</td>
                                        <td><?php echo $row['firstname']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Last Name</td>
                                        <td><?php echo $row['lastname']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>User Name</td>
                                        <td><?php echo $row['username']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td><?php echo $row['email']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Phone</td>
                                        <td><?php echo $row['phone']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Gender</td>
                                        <td><?php echo $row['gender']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Country</td>
                                        <td><?php echo $row['country']; ?></td>
                                    </tr>
                                </table>


                            </div>
                            <div class="col-md-6">
                                <h5 class="text-center my-2">Update Username</h5>
                                <form method="post">
                                    <label>Change Username</label>
                                    <input type="text" name="username" class="form-control" autocomplete="off" placeholder="Enter Username">
                                    <br>
                                    <input type="submit" name="change_username" class="btn btn-success" value="Change Username">
                                </form>
                                <br><br>

                                <h5 class="text-center my-2">Change Password</h5>
                                <form method="post">
                                    <div class="form-group">
                                        <label>Old Password</label>
                                        <input type="password" name="old_password" class="form-control" autocomplete="off" placeholder="Enter Old Password">
                                    </div>
                                    <div class="form-group">
                                        <label>Enter New Password</label>
                                        <input type="password" name="new_password" class="form-control" autocomplete="off" placeholder="Enter New Password">
                                    </div>
                                    <div class="form-group">
                                        <label>Confirm New Password</label>
                                        <input type="password" name="confirm_password" class="form-control" autocomplete="off" placeholder="Confirm New Password">
                                        <br>
                                        <input type="submit" name="change_password" class="btn btn-success" value="Change Password">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php

if (isset($_POST['change_username'])) {
    $new_username = $_POST['username'];
    $query = "UPDATE patient SET username='$new_username' WHERE username='$patient'";
    if (mysqli_query($connect, $query)) {
        echo "Username updated successfully!";

        session_destroy();
        header("Location: patientlogin.php");
        exit();
    } else {
        echo "Error updating username.";
    }
}


if (isset($_POST['change_password'])) {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];


    if ($new_password == $confirm_password) {

        $query = "SELECT password FROM patient WHERE username='$patient'";
        $res = mysqli_query($connect, $query);
        $row = mysqli_fetch_assoc($res);

        if (password_verify($old_password, $row['password'])) {

            $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $update_query = "UPDATE patient SET password='$new_password_hash' WHERE username='$patient'";
            if (mysqli_query($connect, $update_query)) {
                echo "Password updated successfully!";

                session_destroy();
                header("Location: patientlogin.php");
                exit();
            } else {
                echo "Error updating password.";
            }
        } else {
            echo "Old password is incorrect.";
        }
    } else {
        echo "New passwords do not match.";
    }
}
?>