<?php
global $connect;
session_start();
include("../include/connectiondb.php");

$patient = $_SESSION['patient'];

$query = "SELECT SUM(amount_paid) as total_amount FROM income WHERE patient = '$patient'";
$result = mysqli_query($connect, $query);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $total_amount = $row['total_amount'] ? $row['total_amount'] : 0;
} else {
    $total_amount = 0;
}

?>

<!doctype html>
<html lang="en">
<head>
    <title>My Invoice</title>
</head>
<body>
<?php
include("../include/header.php");
?>

<div class="container-fluid">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px;">
                <?php include("../patient/sidenav.php"); ?>
            </div>
            <div class="col-md-10">
                <h3 class="text-center my-3">My Invoice</h3>

                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-6 offset-md-3 jumbotron bg-info">
                            <h4 class="text-center">Total Amount Paid</h4>
                            <p class="text-center">$<?php echo number_format($total_amount, 2); ?></p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
</body>
</html>
