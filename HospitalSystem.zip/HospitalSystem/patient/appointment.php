<?php
global $connect;
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <title>Appointment Page</title>

</head>
<body>
<?php
include("../include/header.php");
include("../include/connectiondb.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = mysqli_real_escape_string($connect, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($connect, $_POST['lastname']);
    $gender = mysqli_real_escape_string($connect, $_POST['gender']);
    $phone = mysqli_real_escape_string($connect, $_POST['phone']);
    $appointment_date = mysqli_real_escape_string($connect, $_POST['appointment_date']);
    $symptoms = mysqli_real_escape_string($connect, $_POST['symptoms']);
    $status = 'Pending';
    $date_booked = date('Y-m-d H:i:s');

    $query = "INSERT INTO appointment (firstname, lastname, gender, phone, appointment_date, symptoms, status, date_booked) 
              VALUES ('$firstname', '$lastname', '$gender', '$phone', '$appointment_date', '$symptoms', '$status', '$date_booked')";

    if (mysqli_query($connect, $query)) {
        echo "<div class='alert alert-success text-center'>Appointment booked successfully!</div>";
    } else {
        echo "<div class='alert alert-danger text-center'>Error: " . mysqli_error($connect) . "</div>";
    }
}
?>

<div class="container-fluid">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px;">
                <?php
                include("../patient/sidenav.php");
                ?>
            </div>
            <div class="col-md-10">
                <h3 class="text-center my-3">Book an Appointment</h3>
                <form method="POST" class="p-3">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="firstname" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="lastname" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Gender</label>
                        <select name="gender" class="form-control" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Appointment Date</label>
                        <input type="date" name="appointment_date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Symptoms</label>
                        <textarea name="symptoms" class="form-control" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-info">Book Appointment</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
